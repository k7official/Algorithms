
    //memset(B, 0, sizeof(B));